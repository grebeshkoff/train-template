Panel Colorer Plugin v 0.9

Author: Igor Afanasyev <igor.afanasyev (at) gmail (dot) com>

License: GPL v.3 (see license.txt)

For latest releases and source code please visit
http://code.google.com/p/panel-colorer/

Description
-----------

Panel Colorer is an innovative and highly experimental plugin for
FAR manager and ConEmu console emulator (it won't work without ConEmu).

Though FAR is a console application, ConEmu adds GUI flavor to it and
allows some behavior a console application alone can't implement.
Panel Colorer uses ConEmu to dynamically change the background of FAR
application based on current FAR panels/windows state.

For screenshots, please visit
http://code.google.com/p/panel-colorer/


Features
--------

* Panels are colored based on volume drive type (fixed, removable,
  etc.), and each type has a set of slightly different colors to
  distinguish one drive from another.

* Each panel features drive description, its size and free/total
  usage meter at the bottom of the panel.

* Volumes mounted as folders (NTFS junctions) are recognized.

* Plugin panels have their own color, too; Panel Colorer recognizes
  most popular FAR plugins and provides special text and images for them.

* Rules for special directories like "C:\Windows\Temp" or ".svn".


Requirements
------------

* FAR 2.0 (build 1661) x86.

* ConEmu 100903 (either x86 or x64 version).


Installation
------------

1 Install FAR.
  http://www.farmanager.com/download.php

2 Install ConEmu into the same folder where FAR is located from.
  http://code.google.com/p/conemu-maximus5/downloads/list

3 Unpack plugin to FAR 'plugins' folder.

4 Start ConEmu (which will load FAR, and plugin will be enabled by default).

5 In ConEmu options, make sure 'Enable plugins' option is turned on.

6 In ConEmu options, adjust background opacity to your liking
  (recommended is the middle value of 127).


TODO
----

* Configurability (currently all coloring rules are hard-coded).

* More rules (plugins, special folders out-of-the-box).


History
-------

0.9 (2010-Sep-04)
-----------------

Initial release (source and binaries published).